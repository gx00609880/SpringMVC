package com.emp;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

/*Adding this annotation to an @Configuration class 
imports the Spring MVC configuration 
from WebMvcConfigurationSupport, e.g.: */
@Configuration
@ComponentScan(basePackages = "com.emp")
@EnableWebMvc
@PropertySource(value = {"classpath:/application.properties"})
@EnableAspectJAutoProxy
public class SpringConfig {

	@Value("${database.drivername}")
	private String driverName;
	@Value("${database.url}")
	private String url;
	@Value("${database.username}")
	private String userName;
	@Value("${database.password}")
	private String password;
	
	@Bean //Define DataSource
	public DataSource getDataSource() {
		
		DataSource dataSource = new DataSource();
		dataSource.setUrl(url);
		dataSource.setUsername(userName);
		dataSource.setDriverClassName(driverName);
		dataSource.setPassword(password);
		
		return dataSource;
	}
	
	@Bean // Define JDBCTemplate
	public JdbcTemplate getTemplate() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(getDataSource());
		return jdbcTemplate;
	}

}