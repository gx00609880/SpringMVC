package com.emp.model;

//POJO - getter and setters
public class Employee {

	private int empId;
	private String empName;
	private float empRating;
	
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empRating=" + empRating + "]";
	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	public Employee(int empId, String empName, float empRating) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empRating = empRating;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public float getEmpRating() {
		return empRating;
	}

	public void setEmpRating(float empRating) {
		this.empRating = empRating;
	}
	
	
}
