package com.emp.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.emp.model.Employee;

@Repository
public class EmployeeDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;
	//Step1: CRUD - Insert
	
	public boolean insertEmployee(Employee employee) {
		
		String insertQuery = "insert into employee values(?,?,?)";
		int result = 0;
		
		try {
		result = jdbcTemplate.update(insertQuery, 
				new Object[]{employee.getEmpId(),employee.getEmpName()
						,employee.getEmpRating()});
		}catch(DataAccessException dataAccessException) {
			String msg = dataAccessException.getMessage();
			System.out.println(msg);
		}
		System.out.println(result);
		if(result>0) {
			return true;
		}else {
			return false;
		}
	}
	
	//Step2: Retrieve the Records
	@Autowired
	EmployeeRowMapper employeeRowMapper;
	public List<Employee> getAllEmployees(){
		
		String sql = "select * from employee";
		
		return jdbcTemplate.query(sql, employeeRowMapper);
	}
	
	public Employee searchEmployeeByID(int empId) {
		
 return jdbcTemplate.queryForObject("select * from employee where empid=?", 
				new Object[] {empId},
				employeeRowMapper);
	}
}
