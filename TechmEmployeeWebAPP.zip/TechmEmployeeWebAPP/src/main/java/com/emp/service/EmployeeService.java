package com.emp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emp.dao.EmployeeDAO;
import com.emp.model.Employee;

@Service
public class EmployeeService {

	List<Employee> employees = new ArrayList<Employee>();
	
	//Manual No-Arg Constructor
	public EmployeeService() {
	}
	
	/*
	 * public EmployeeService(boolean a) { System.out.println("Constructor Call");
	 * employees.add(new Employee(101,"Sabari",2.4f)); employees.add(new
	 * Employee(102,"Balaji",3.1f)); employees.add(new
	 * Employee(103,"Parthasarathy",5.0f)); }
	 */
	
	@Autowired
	EmployeeDAO employeeDAO;
	public boolean insertEmployee(Employee employee) {
		return employeeDAO.insertEmployee(employee);
	}
	
	
	public List<Employee> getAllEmployees(){
		return employeeDAO.getAllEmployees(); 
	}
	
	public Employee searchEmployeeByID(int empId) {
		return employeeDAO.searchEmployeeByID(empId);
	}
	
	
}
