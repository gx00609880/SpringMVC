package com.rest;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;


public class WebConfigCode  implements WebApplicationInitializer {

	
	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		
		//Step 1: Enable Application Context
		
		AnnotationConfigWebApplicationContext iocContext = new AnnotationConfigWebApplicationContext();
		
		iocContext.register(SpringConfig.class);
		
		//Step 2:Register Your Dispatcher Servlet
		
		ServletRegistration.Dynamic servletRegistration = 
				servletContext.addServlet("ds",new DispatcherServlet(iocContext));
		
		//Step 3: Load The DS on Startup 
		
		servletRegistration.setLoadOnStartup(1);
		
		servletRegistration.addMapping("/");
	
	}

}
