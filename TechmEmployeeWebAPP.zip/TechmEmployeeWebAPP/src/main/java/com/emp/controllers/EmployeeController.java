package com.emp.controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.emp.model.Employee;
import com.emp.service.EmployeeService;

@RestController
@RequestMapping("/emp")
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;
	
	//n-number of endpoint Methods
	//@RequestMapping(value="/msg",method = RequestMethod.GET)
	//@ResponseBody
	//URI Templating
	//http://localhost:8080/TechmEmployeeWebAPP/emp/msg/sabari
	@GetMapping("/msg/{name}/{age}")
	//@PostMapping
	//@DeleteMapping
	public String getMessage(@PathVariable(name = "name")
	String n,@PathVariable int age) {
		return "Hi Welcome To TechM"+n+age;
	}
	
	@GetMapping("/allemp")
	public List<Employee> getAllEmp(){
		System.out.println("Search BY GET ALL EMPLOYEE");
		return employeeService.getAllEmployees();
	}
	
	@GetMapping("/searchbyid/{empId}")
	public Employee searchEmployeeByID(@PathVariable int empId) {
		System.out.println("Search BY Employee ID");
		return employeeService.searchEmployeeByID(empId);
	}
	
	@GetMapping("/storeemp/{empId}/{empName}/{empRating}")
	public boolean insertEmp(
			@PathVariable int empId,
			@PathVariable String empName,
			@PathVariable float empRating ){
		Employee employee = new Employee(empId,empName,empRating);
		return employeeService.insertEmployee(employee);
	}
	
	@PostMapping("/insertemp")
	public boolean insertEmp(@RequestBody Employee employee){
		return employeeService.insertEmployee(employee);
	}
}
