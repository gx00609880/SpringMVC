package com.emp.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.emp.model.Employee;

@Component
public class EmployeeRowMapper implements RowMapper<Employee>{

	@Override
	public Employee mapRow(ResultSet rs, int rowNum) 
			throws SQLException {
		
		int id = rs.getInt("empid");
		String name  = rs.getString("empname");
		float rating = rs.getFloat("empgrade");
		
		Employee employee = new Employee(id,name,rating);
		
		return employee;
	}
}
