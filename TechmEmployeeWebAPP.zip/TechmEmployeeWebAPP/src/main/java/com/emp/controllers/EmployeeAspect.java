package com.emp.controllers;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
//Open Declaration org.aspectj.lang.annotation.Aspect
@Component
@Aspect
public class EmployeeAspect {

	@Before("execution(* EmployeeController.getAllEmp())")
	public void beforeGetAllEmployees(JoinPoint joinPoint) {
	System.out.println("Get All Employee METHOD Called");	
	}
	
		@Pointcut("execution(* EmployeeController.searchEmployeeByID(..))")
		public void dummy1() {
			
		}
	
	  @AfterReturning("dummy1()")
	  public void beforeGetSearchByEmployee(JoinPoint joinPoint) {
	  System.out.println("SEARCH Employee  METHOD Called"); }
	 
	
}
